#!/usr/bin/php
<?php
    function change($matches) {
    $ret = str_replace($matches[1],strtoupper($matches[1]), $matches[0]);
        return ($ret);
    }
$name = '/<a.*?>(.*?)</';
$title = '/<a.*?title="(.*?)">/';
if ($argc >= 2) {
    if ($fd = fopen($argv[1], "r") === false) {
        exit();
    }
    while (!feof($fd)) {
        $line = fgets($fd);
        $line = preg_replace_callback($name, "change", $line);
        $line = preg_replace_callback($title, "change", $line);
        echo $line;
    }
    fclose ($fd);
    echo "\n";
} else {
    exit();
}
?>