#!/usr/bin/php
<?php
# https://superuser.com/questions/133987/difference-betwen-who-and-finger-command-in-unix-linux

$array = array();
$ret_value = 0;
$finger_l = "finger -l";
$finger = "finger";

exec($finger, $array, $ret_value);
if ($ret_val != 0)
{
    echo "error while executing the shell command $finger\n";
}
$array = array_slice($array, 1);
$pattern = '/^(?:[[:alpha:]]{3,})/';
foreach ($array as $key => $value) {
    preg_match($pattern, $value, $matches);
    $array[$key] = $matches[0]."   ";
}
$array = array_values($array);
$tty_array = array();
exec($finger_l, $tty_array, $ret_value);
if ($ret_val != 0)
{
    echo "error while executing the shell command $finger_l\n";
}
$tty = '/on (.*)/';
foreach ($tty_array as $key => $value) {
    preg_match($tty, $value, $matches);
     $tty_array[$key] = $matches[1];
}
$tty_array = array_filter($tty_array);
$tty_array = array_values($tty_array);
foreach ($array as $key => $value) {
    $array[$key] = $array[$key]."".$tty_array[$key];
    echo $array[$key]."\n";
}
?>