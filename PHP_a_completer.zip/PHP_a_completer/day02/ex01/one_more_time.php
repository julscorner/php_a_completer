#!/usr/bin/php
<?php
if ($argc != 2) {
    exit();
}
$input = $argv[1];
$input = explode(' ', $input);
if (count($input) != 5) {
    echo_exit();
}
$days_french = array('/[Ll]undi/','/[Mm]ardi/','/[Mm]ercredi/','/[Jj]eudi/', '/[Vv]endredi/','/[Ss]amedi/','/[Dd]imanche/');
$days_english = array('Mnonday','Tuesday','Wenesday','Thursday', 'Friday','Saturday','Sunday');
$input[0] = preg_replace($days_french, $days_english, $input[0]);

$months_french = array('/[Ss]eptembre/','/[Oo]ctobre/','/[Nn]ovembre/','/[Dd]ecembre/','/[Jj]anvier/','/[Ff][ée]vrier/','/[Mm]ars/','/[Aa]vril/','/[Mm]ai/','/[Jj]uin/','/[Jj]uillet/','/[Aa]o[uû]t/');
$months_english = array('September','October','November','December', 'January','February','March', 'April', 'May', 'June', 'July', 'August');
$input[2] = preg_replace($months_french, $months_english, $input[2]);

$time = $input[4];
$day = $input[0];
$month = $input[2];
$date = $input[1];
$year = $input[3];

date_default_timezone_set('Europe/Paris')."\n"; # set correct timezone (instead of UTC)
$str = strtotime("$day $date $month $year $time");
if ($str === false) {
    echo_exit();
}
print($str)."\n";

 function echo_exit() {
    echo "Wrong Format"."\n";
    exit();
 }

 function str_len($input) {
    for ($i = 0; $input[$i]; $i++) { ; }
    return $i;
}

?>