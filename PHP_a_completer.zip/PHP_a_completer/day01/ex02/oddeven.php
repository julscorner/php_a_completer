#!/usr/bin/php
<?php
while (1) {
    echo "Entrez un nombre: ";
    $input = rtrim(fgets(STDIN));
	if (feof(STDIN))
	{
		echo "\n";
		exit();
	}
    if (authorized_characters($input) == true && str_len($input) == true) {
        if (is_even($input) == true) {
            print("The number $input is even\n");
        }
        else {
            print("The number $input is odd\n");
        }
    }
    else {
        print("'$input' is not a number\n");    
    }

}

function authorized_characters ($input) {
    for ($i = 0; $input[$i]; $i++) {
        if ($i == 0  && $input[0] == '-')
        {
            continue;
        }
        if (!($input[$i] >= '0' && $input[$i] <= '9'))
        {
         return false;
        }
    }
   return true;
}

function str_len($input) {
 for ($i = 0; $input[$i]; $i++) { ; }
 return $i;
}

function is_even($input) {
    $i = str_len($input) - 1;

    if ( $input[$i] % 2 == 0) {
        return true;
    }
    else {
        return false;
    }
}
?>

