#!/usr/bin/php
<?php
$exclude = array($argv[0]);
foreach($argv as $value)
{
if (in_array($value, $exclude)) { continue; }
  echo "$value\n";
}
?>
