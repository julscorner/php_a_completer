#!/usr/bin/php
<?php
function ft_split($input) {
    preg_replace('/ +/',' ', $input);
    $split = explode(' ', $input);
    sort($split);
    return $split;
}
?>