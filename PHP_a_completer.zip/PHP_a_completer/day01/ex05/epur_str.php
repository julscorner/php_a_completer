#!/usr/bin/php
<?php
$input = trim($argv[1]," ");
$ret = preg_replace('/[[:space:]]+/',' ', $input);
print($ret."\n");
?>
