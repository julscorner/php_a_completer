<?php
//php -S e3r5p11.42.fr:8080 phpinfo.php
//curl http://e3r5p11:8080/day03/ex01/phpinfo.php
phpinfo();
?>
