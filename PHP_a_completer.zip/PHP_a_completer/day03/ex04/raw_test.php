<?php
header('Content-Type: text/plain');
?>
<html><body>Hello</body></html>
