<?php
header("Content-type: image/png");
readfile("../img/42.png");
?>
