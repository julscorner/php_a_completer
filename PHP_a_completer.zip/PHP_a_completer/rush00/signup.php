<?php
require "header.php";
?>

<body>
    <div class="inscription">
        <table class="tab_inscription">
            <h1>Inscription</h1>
            <form action="include/signup.inc.php", method="POST">
                <tr>
                    <td>
                        <input class="inscription_input" type="text" name="login" value="" placeholder="nom d'utilisateur">
                    </td>
                </tr>
                <tr>
                    <td >
                        <input class="inscription_input" type="text" name="email" value="" placeholder="adresse mail">
                    </td>
                </tr>
                <tr>
                    <td >
                        <input class="inscription_input" type="password" name="passwd" value="" placeholder="mot de passe">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input class="inscription_input" type="password" name="confirm_passwd" value="" placeholder="confirmer mot de passe">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input class="inscription_submit" type="submit" name="submit" value="S'inscrire">
                    </td>
                </tr>
            </form>
        </table>
    </div>
</body> 

<?php
require "footer.php";
?>