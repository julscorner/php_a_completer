<?php
    require "admin.php";

?>
<p class="titres">AJOUTER UNE CATÉGORIE</p>
 <body>
    <div>
        <table class="tab_addcategory">
            <form enctype="multipart/form-data" action="include/addcategory.inc.php", method="POST">
                <tr>
                    <td>
                        <input class="addcategory_input" type="text" name="categoryname" placeholder="nom de la category" required>
                    </td>                   
                    <td>
                        <input class="add_button" type="submit" name="addcategory_submit" value="AJOUTER">
                    </td>        
                    <tr>
                            <p><?php
                            if (isset($_GET['erreur']) || isset($_GET['categorie']))
                            {
                                echo '<div class="admin_msg">';
                                if ($_GET['erreur'] == "erreursql")
                                    echo '<p>Cette catégorie n\'existe pas</p>';
                                if ($_GET['erreur'] == "nomcatégoriedéjàexistant")
                                    echo '<p>Cette catégorie existe déjà</p>';
                                if ($_GET['categorie'] == "ajouter")
                                    echo '<p>Catégorie ajouté avec succes</p>';
                                echo '</div>';
                            }
                            ?></p>
                    </tr>   
                </tr>
            </form>
        </table>            
    </div>        
</body> 



