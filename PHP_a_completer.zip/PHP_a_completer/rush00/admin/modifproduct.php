<?php
 

 
    require "admin.php";
    require "../include/db.inc.php";

    $query = "SELECT * FROM category";
    $res = mysqli_query($conn, $query);
    while ($row = mysqli_fetch_array($res))
    {
        $options = $options."<option>$row[nameCategory]</option>";
    }
    
    $id = $_GET['id'];
    $query2 = "SELECT * FROM products WHERE idProducts = '$id'";
    $res2 = mysqli_query($conn, $query2);
    $row2 = mysqli_fetch_array($res2);


?>

<p class="titres">MODIFIER UN PRODUIT</p>
 <body>
    <div>
        <table class="tab_modifproduct">
            <form enctype="multipart/form-data" action="include/modifproduct.inc.php", method="POST">
                <tr>
                    <tr>
                        <td>    
                            Modifier le nom du produit:
                        </td>
                        <td>
                            <input class="modifcategory_input" type="text" name="modifproduct_name" placeholder="<?php echo $row2['nameProducts']?>">
                            <input type="hidden" name="idproduct" value="<?php echo $id ?>">
                            <input type="hidden" name="oldnameproduct" value="<?php echo $row2['nameProducts'] ?>">
                        </td>
                        <td>
                            <input class="modif_button" type="submit" name="modifproduct_name_submit" value="MODIFIER">
                        </td>
                    </tr>
                    <tr>
                        <td>    
                            Modifier le prix du produit:
                        </td>    
                        <td >
                            <input class="addproduct_input" type="number" step=0.01 min="0.01" name="modifproduct_price" placeholder="<?php echo $row2['priceProducts']?>" >
                        </td>
                        <td>
                            <input class="modif_button" type="submit" name="modifproduct_price_submit" value="MODIFIER">
                        </td>
                    <tr>                     
                        <td>    
                            Modifier la catégorie du produit:
                        </td>
                        <td>
                            <select class="ddmenu" name="modifproduct_cat">
                                <option value="">modifier catégorie</option> 
                                <?php echo $options; ?>
                            </select>
                        </td>
                        <td>
                            <input class="modif_button" type="submit" name="modifproduct_cat_submit" value="MODIFIER">
                        </td>
                    </tr>   
                    <tr>    
                        <td>    
                            Modifier l'image du produit:
                        </td>
                        <td >
                        <br/ >
                           <input type="file" name="productimg" >
                        </td>
                        <td>
                           <input class="modif_button" type="submit" name="modifproduct_img_submit" value="MODIFIER">
                        </td>
                    </tr>
                    <tr>    
                        <td>    
                            Modifier la description du produit:
                        </td>
                        <td >
                        <br/ ><br/ >
                            <textarea name = "modifproduct_desc" rows="15" cols="40" placeholder="<?php echo $row2['descProducts']?>"></textarea>
                        </td>
                        <td>
                            <input class="modif_button" type="submit" name="modifproduct_desc_submit" value="MODIFIER">
                        </td>
                    </tr>
                </tr>

            </form>                

        </table>
    </div>
</body> 



