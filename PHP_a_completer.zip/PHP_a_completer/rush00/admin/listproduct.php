<?php

    require "admin.php";
    require "../include/db.inc.php";


    $query = "SELECT * FROM products";
    $res = mysqli_query($conn, $query);

?>
<p class="titres">LISTE DES PRODUITS</p>
<body>
   <div>
        <table class="tab_listproduct">
                <tr>
                          <th>Produit</th>
                          <th>Prix du produit</th>
                          <th>Catégorie</th>
                          <th>Sous catégorie</th>
                          <th>Image</th>
                </tr>
                <?php
                    while ($row = mysqli_fetch_array($res)) 
                    {
                        echo '
                        <tr>
                            <td>'.$row['nameProducts'].'</td>
                            <td>'.$row['priceProducts'].'</td>
                            <td>'.$row['catProducts'].'</td>
                            <td>'.$row['subcatProducts'].'</td>
                            <td><img width="80px" src="'.$row['imgProducts'].'"></td> 
                            <td><a class="modif_button" href="modifproduct.php?id='.$row['idProducts'].'">Modifier</a></td>
                            <td><form action="include/delproduct.inc.php" method="POST">
                                <button type="submit" class="del_button" name="delproduct_submit" value='.$row['idProducts'].'>supprimer</button>
                            </form></td>

                        </tr>
                        ';
                    }
                ?> 
                <br/ ><br/ ><br/ ><br/ >
                        <td><a class="add_button" href="addproduct.php">Ajouter produit</a></td>
                        			
                                                      
        </table>
    </div>
</body> 

