<?php



    require "admin.php";
    require "../include/db.inc.php";


    $query = "SELECT * FROM category ORDER BY nameCategory";
    $res = mysqli_query($conn, $query);
?>



<body>
    <div>
        <table class="tab_listsubcategory">
            <p class="titres">LISTE DES CATÉGORIES</p>
                <br/ >
                <tr>       
                    <th>Catégorie</th>
                </tr>
                <?php
                    while ($row = mysqli_fetch_array($res)) 
                    {
                        echo '
                        <tr>
                            <td>'.$row['nameCategory'].'</td>
                            <td><form action="include/delcategory.inc.php" method="POST">
                                <button type="submit" class="del_button" name="delcat_submit" value='.$row['idCategory'].'>supprimer</button>
                            </form></td>
                         
                        </tr>
                        ';
                    }
                ?> 
                <br/ ><br/ ><br/ ><br/ >
                <form enctype="multipart/form-data" action="include/addcategory.inc.php", method="POST">
                    <tr>
                        <td>
                            <input class="addcategory_input" type="text" name="categoryname" placeholder="Ajouter une categorie" required>
                        </td>                   
                        <td>
                            <input class="add_button" type="submit" name="addcategory_submit" value="AJOUTER">
                        </td>
                    </tr>
                </form>
                          
        </table>
    </div>
</body> 

