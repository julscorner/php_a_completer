<?php

    require "admin.php";
    require "../include/db.inc.php";

    $query = "SELECT * FROM category";
    $res = mysqli_query($conn, $query);
    while ($row = mysqli_fetch_array($res))
    {
        $options = $options."<option>$row[nameCategory]</option>";
    }
?>

<p class="titres">MODIFIER UNE CATÉGORIE</p>
 <body>
    <div>
        <table class="tab_modifcategory">
            <form enctype="multipart/form-data" action="include/modifcategory.inc.php", method="POST">
                <tr>       
                    <td>                 
                    <select class="ddmenu" name="categoryname" required>
                        <option value="">Choisir une catégorie</option> 
                        <?php echo $options; ?>
                    </select>
                    </td>
                    <td>                         
                    <input class="modifcategory_input" type="text" name="modifcategory_name" placeholder="nouveau nom de la category">
                    <?php
                        if (isset($_GET['erreur']) || isset($_GET['categorie']))
                        {
                            echo '<div class="modifcat_msg">';
                            if ($_GET['categorie'] == 'modifier')
                                echo '<p>Catégorie modifié avec succes</p>';
                            if ($_GET['erreur'] == 'champsvide')
                                echo '<p>Veuillez entrer une nouvelle catégorie</p>'; 
                            echo '</div>';
                        }
                    ?>
                    </td>
                <td>
                        <input class="modifcategory_button" type="submit" name="modifcategory_submit" value="MODIFIER">
                </td>
                    </td>
                </tr>

            </form>                

        </table>
    </div>
</body> 



