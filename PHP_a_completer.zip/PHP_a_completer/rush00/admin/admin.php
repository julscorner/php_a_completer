<?php
session_start();

if (empty($_SESSION['adminid']))
   {
   echo '<body>
               <div style="background-color: lightgrey; width: 500px; height: 200px; margin: 0 auto; border-radius: 40px; text-align: center;">
                    <h1 style="color: red; padding-top: 50px; font-family: sans-serif;">ACCES INTERDIT</h1>
                    <a style="color: black;" href="../index.php"> retour</a>
                </div>
        </body>';
   
   exit();
   }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../style_admin.css?version=1">
        <title>Vente De Film</title>
    </head>
    <header>
        <a href="listproduct.php"><img src="../img/logo.jpg" alt="logo"></a> 
        <nav>
            
            <div class="menu">
                <h1>Produits</h1>
                    <a href="listproduct.php">Liste des produits</a>
                    <a href="addproduct.php">Ajouter produit</a>
                    <!-- <li><a class="" href="modifproduct.php">Modifier produit</a></li> -->
                    <!-- <a class="submenu" href="#">Supprimer produit</a> -->
                <h1>Catégories</h1>
                    <a class="submenu" href="listcategory.php">Liste de catégorie</a>
                    <!-- <a class="submenu" href="addcategory.php">Ajouter catégorie</a> -->
                    <a class="submenu" href="modifcategory.php">Modifier catégorie</a>
                    <!-- <a class="submenu" href="delcategory.php">Supprimer catégorie</a>                 -->
                <h1>Utilisateurs</h1>
                    <a class="submenu" href="listusers.php">Liste utilisateur</a>
                    <a class="submenu" href="addusers.php">Ajouter utilisateur</a>
                    <!-- <a class="submenu" href="#">Modifier utilisateur</a>
                    <a class="submenu" href="#">Supprimer utilisateur</a> -->
            </div>
            <div class="log">
            <form action="../include/login.inc.php" method="POST">
                   
                    <a class="signup" href="../include/logout.inc.php">Déconnexion</a>
                    <p class="admin_accompt">Compte administrateur</p>
            </form> 
            </div>
        </nav>
    </div>
    </header>
    <body>
        
    </body>
</html>