<?php

    if (isset($_POST['delusers_submit']))
    {
        require "../../include/db.inc.php";

        $id = $_POST['delusers_submit'];

        $query = "DELETE FROM users WHERE idUsers = '$id'" ;
        mysqli_query($conn, $query);
        header("location: ../listusers.php?id=$id&user=supprimer");
        exit();
    }
