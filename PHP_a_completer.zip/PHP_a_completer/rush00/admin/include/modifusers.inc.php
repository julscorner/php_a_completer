<?php
    require "../../include/db.inc.php";
if (isset($_POST['modifuser_level_submit']))
    {

        $relevel = $_POST['listleveluser'];
        $id = $_POST['idproduct'];
       
        if (empty($relevel))
        {
            header("location: ../modifproduct.php?id=$id&erreur=champsvide");
            exit();
        }
        else
        {
            $query = "UPDATE users SET administrator = '$relevel' WHERE idUsers = '$id'" ;
            mysqli_query($conn, $query);
            header("location: ../modifusers.php?id=$id&leveluser=modifier");
            exit();
        }
    }

    if (isset($_POST['modifuser_name_submit']))
    {

        $rename = $_POST['username'];
        $id = $_POST['idproduct'];
       
        if (empty($rename))
        {
            header("location: ../modifproduct.php?id=$id&erreur=champsvide");
            exit();
        }
        else if ($rename == $name)
        {
            header("location: ../modifproduct.php?id=$id&erreur=nomexistedeja");
            exit();
        }
        else
        {
            $query = "UPDATE users SET nameUsers = '$rename' WHERE idUsers = '$id'" ;
            mysqli_query($conn, $query);
            header("location: ../modifusers.php?id=$id&nomuser=modifier");
            exit();
        }
    }
        if (isset($_POST['modifuser_mail_submit']))
        {
    
            $remail = $_POST['usermail'];
            $id = $_POST['idproduct'];
           
            if (empty($remail))
            {
                header("location: ../modifproduct.php?id=$id&erreur=champsvide");
                exit();
            }
            else
            {
                $query = "UPDATE users SET mailUsers = '$remail' WHERE idUsers = '$id'" ;
                mysqli_query($conn, $query);
                header("location: ../modifusers.php?id=$id&nomuser=modifier");
                exit();
            }

            if (isset($_POST['modifuser_pwd_submit']))
            {
        
                $repwd = $_POST['userpwd'];
                $id = $_POST['idproduct'];
               
                if (empty($repwd))
                {
                    header("location: ../modifproduct.php?id=$id&erreur=champsvide");
                    exit();
                }
                else
                {   $hashpwd = hash('whirlpool', $repwd);
                    $query = "UPDATE users SET pwdUsers = '$hashpwd' WHERE idUsers = '$id'" ;
                    mysqli_query($conn, $query);
                    header("location: ../modifusers.php?id=$id&nomuser=modifier");
                    exit();
                }
            }
}