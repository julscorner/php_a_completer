<?php

    if (isset($_POST['delproduct_submit']))
    {
        require "../../include/db.inc.php";

        $id = $_POST['delproduct_submit'];

        $query = "DELETE FROM products WHERE idProducts = '$id'" ;
        mysqli_query($conn, $query);
        header("location: ../listproduct.php?id=$id&nomproduit=supprimer");
        exit();
    }
