<?php
if (isset($_POST['addcategory_submit']))
{
    require '../../include/db.inc.php';
    $categoryname = $_POST['categoryname'];

     // error empty fields

    if (empty($categoryname))
    {
         header("location: ../addcategory.php?erreur=champsvide");
         exit();
    }

      // check if name already used

    else 
    {
        $query = "SELECT nameCategory FROM category WHERE namecategory=?";
        $stmt = mysqli_stmt_init($conn);                                    // Initialise une commande MySQL
        if (!mysqli_stmt_prepare($stmt, $query))                           // Prépare une requête SQL pour l'exécution
        {
            header("location: ../addcategory.php?erreur=erreursql");
            exit();
        }
        else
        {
            mysqli_stmt_bind_param($stmt, "s", $categoryname);           // Lie des variables à une requête MySQL
            mysqli_stmt_execute($stmt);                                  // Exécute une requête préparée
            mysqli_stmt_store_result($stmt);                             // Stocke un jeu de résultats depuis une requête préparée
            $resultCheck = mysqli_stmt_num_rows($stmt);                  // Retourne le nombre de lignes d'un résultat MySQL
            if ($resultCheck > 0)
            {
                header("location: ../listcategory.php?erreur=nomcatégoriedéjàexistant");
                exit();
            }
            else
            {
                $query = "INSERT INTO category(nameCategory) VALUES (?)";
                $stmt = mysqli_stmt_init($conn);
                if (!mysqli_stmt_prepare($stmt, $query))
                {
                    header("location: ../addcategory.php?erreur=erreursql");
                    exit();
                }
                else 
                {
                    mysqli_stmt_bind_param($stmt, "s", $categoryname);
                    mysqli_stmt_execute($stmt);
                    header("location: ../listcategory.php?categorie=ajouter");
                    exit();
                }
            }
        }
    }
     mysqli_stmt_close($stmt);
     mysqli_close($conn);
}
else
{
     header("location: ../addcategory.php");
     exit();
}

