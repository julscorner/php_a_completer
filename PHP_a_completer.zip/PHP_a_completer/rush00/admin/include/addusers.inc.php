<?php   
    

if (isset($_POST['addusers_submit']))
{
    require "../../include/db.inc.php";

    $level = $_POST['listleveluser'];
    $name = $_POST['username'];
    $email = $_POST['usermail'];
    $pwd = $_POST['userpwd'];   
   
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
    {
         header("location: ../addusers.php?erreur=mailinvalide&login=".$name);
         exit();
    }
    else
    {
        $hashpwd = hash('whirlpool', $pwd);
        $query = "INSERT INTO users(nameUsers, emailUsers, pwdUsers, administrator) VALUES ('$name', '$email', '$hashpwd', '$level')";
        if (mysqli_query($conn, $query))
           header("location: ../addusers.php?ajout=réussi");
        else
            echo "TESTES";
           exit();
    }
}
else 
{
    header("location: ../addusers.php?ajout=fail");
    exit();
}

?>