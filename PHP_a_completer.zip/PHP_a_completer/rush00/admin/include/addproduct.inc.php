<?php
if (isset($_POST['addproduct_submit']))
{
   require '../../include/db.inc.php';
    $productname = $_POST['productname'];
    $productprice = $_POST['productprice'];
    $productdesc = $_POST['productdesc'];
    $souscategorie = $_POST['listsubcatname'];
    $categorie = $_POST['listcatname'];
    //$souscategorie = $_POST['categorie'];

     // error empty fields

    if (empty($souscategorie))
    {
        header("location: ../addproduct.php?erreur=erreur1");
        exit();
   }

    if (empty($productname) || empty($productprice))
    {
         header("location: ../addproduct.php?erreur=champsvide");
         exit();
    }

      // check if name already used

    else 
    {
        $sql = "SELECT nameproducts FROM products WHERE nameproducts=?";
        $stmt = mysqli_stmt_init($conn);                                 //Initialise une commande MySQL
        if (!mysqli_stmt_prepare($stmt, $sql))                           //Prépare une requête SQL pour l'exécution
        {
            header("location: ../addproduct.php?erreur=erreursql");
            exit();
        }
        else
        {
            mysqli_stmt_bind_param($stmt, "s", $productname);            // Lie des variables à une requête MySQL
            mysqli_stmt_execute($stmt);                                  // Exécute une requête préparée
            mysqli_stmt_store_result($stmt);                             // Stocke un jeu de résultats depuis une requête préparée
            $resultCheck = mysqli_stmt_num_rows($stmt);                  // Retourne le nombre de lignes d'un résultat MySQL
            if ($resultCheck > 0)
            {
                header("location: ../addproduct.php?error=nomproduitdéjàexistant");
                exit();
            }
            else
            {
                // upload image

                $targetDir = "../../img/";
                $targetDir1 = "../img/";
                $targetFile = $targetDir . basename($_FILES['productimg']['name']);
                $targetFile1 = $targetDir1 . basename($_FILES['productimg']['name']);
                $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
                if ($check = getimagesize($_FILES['productimg']['tmp_name']) !== false)
                {
                        if (!(move_uploaded_file($_FILES['productimg']['tmp_name'], $targetFile)))
                        {
                            header("Location: ../addproduct.php?error=couldnotuploadfile4");
                            exit();
                        }
                }
                else
                {
                    header("Location: ../addproduct.php?error=couldnotuploadfile1");
                    exit();
            }
                
            $sql = "INSERT INTO products(nameProducts, priceProducts, imgProducts, descProducts, subcatProducts, catProducts) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_stmt_init($conn);
            if (!mysqli_stmt_prepare($stmt, $sql))
            {
                    header("location: ../addproduct.php?erreur=erreursql");
                    exit();
            }
            else 
            {
                    mysqli_stmt_bind_param($stmt, "sdssss", $productname, $productprice, $targetFile1, $productdesc, $souscategorie, $categorie);
                    mysqli_stmt_execute($stmt);
                    header("location: ../addproduct.php?ajout=réussi");
                    exit();
            }
        }
        }
    }
     mysqli_stmt_close($stmt);
     mysqli_close($conn);
}
else
{
     header("location: ../addproduct.php");
     exit();
}

