<?php

    if (isset($_POST['delcat_submit']))
    {
        require "../../include/db.inc.php";

        $id = $_POST['delcat_submit'];

        $query = "DELETE FROM category WHERE idCategory = '$id'" ;
        mysqli_query($conn, $query);
        header("location: ../listcategory.php?id=$id&categorie=supprimer");
        exit();
    }
