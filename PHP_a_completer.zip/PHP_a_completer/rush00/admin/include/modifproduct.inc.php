<?php
    require "../../include/db.inc.php";
    if (isset($_POST['modifproduct_name_submit']))
    {

        $rename = $_POST['modifproduct_name'];
        $name = $_POST['oldnameproduct'];
        $id = $_POST['idproduct'];
       
        if (empty($rename))
        {
            header("location: ../modifproduct.php?id=$id&erreur=champsvide");
            exit();
        }
        else if ($rename == $name)
        {
            header("location: ../modifproduct.php?id=$id&erreur=nomexistedeja");
            exit();
        }
        else
        {
            $query = "UPDATE products SET nameProducts = '$rename' WHERE idProducts = '$id'" ;
            mysqli_query($conn, $query);
            header("location: ../modifproduct.php?id=$id&nomproduit=modifier");
            exit();
        }
    }

    if (isset($_POST['modifproduct_price_submit']))
    {
        $reprice = $_POST['modifproduct_price'];
        $id = $_POST['idproduct'];
       
        if (empty($reprice))
        {
            header("location: ../modifproduct.php?id=$id&erreur=champsvide");
            exit();
        }
        else
        {
            $query = "UPDATE products SET priceProducts = '$reprice' WHERE idProducts = '$id'" ;
            mysqli_query($conn, $query);
            header("location: ../modifproduct.php?id=$id&prixproduit=modifier");
            exit();
        }
    }

    if (isset($_POST['modifproduct_cat']))
    {
        $recat = $_POST['modifproduct_cat'];
        $id = $_POST['idproduct'];


        if (empty($recat))
        {
            header("location: ../modifproduct.php?id=$id&erreur=champsvide");
            exit();
        }
        else
        {
            $query = "UPDATE products SET subcatProducts = '$recat' WHERE idProducts = '$id'" ;
            if (mysqli_query($conn, $query))
                header("location: ../modifproduct.php?id=$id&categorieproduit=modifier");
            else
            {
                echo("Error description: " . mysqli_error($conn));
                exit();
            }

        }
    }
?>






