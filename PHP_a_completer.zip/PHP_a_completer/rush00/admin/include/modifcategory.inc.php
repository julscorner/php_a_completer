<?php
    if (isset($_POST['modifcategory_submit']))
    {
        require "../../include/db.inc.php";

        $rename = $_POST['modifcategory_name'];
        $name = $_POST['categoryname'];
        
        if (empty($rename) || empty($name))
        {
            header("Location: ../modifcategory.php?erreur=champsvide");
            exit();
        }

        if (!empty($name))
        {
            $sql = "SELECT nameCategory FROM category WHERE nameCategory = ?";
            $stmt = mysqli_stmt_init($conn);
            if (!mysqli_stmt_prepare($stmt, $sql)){
                header("Location: ../modifcategory.php?erreur=erreursql");
                exit();
            }
            mysqli_stmt_bind_param($stmt, 's', $name);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            $res = mysqli_stmt_num_rows($stmt);
            if ($res == 1)
            {
                $sql = "UPDATE category SET nameCategory = '$rename' WHERE nameCategory = '" .  mysqli_real_escape_string($conn, $name) . "'" ;  //Protège les caractères spéciaux d'une chaîne pour l'utiliser dans une requête SQL, en prenant en compte le jeu de caractères courant de la connexion
                mysqli_query($conn, $sql);
                header("location: ../modifcategory.php?categorie=modifier");
                exit();

            }
            else
            {
                header("Location: ../modifcategory.php?erreur=erreursql");
                exit();
            }
        }
    }
    else
    {
        header("Location: ../../index.php");
        exit();
    }
    
?>