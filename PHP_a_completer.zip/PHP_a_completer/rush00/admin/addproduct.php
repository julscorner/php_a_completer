<?php

    require "admin.php";
    require "../include/db.inc.php";
    

    $sql = "SELECT * FROM types";
    $res = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_array($res))
    {
        $options = $options."<option>$row[nameType]</option>";
    } 
    $sql2 = "SELECT * FROM category";
    $res2 = mysqli_query($conn, $sql2);
    while ($row = mysqli_fetch_array($res2))
    {
        $subcat = $subcat."<option>$row[nameCategory]</option>";
    }
?>
<p class="titres">AJOUTER UN PRODUIT</p>
<body>
    <div>
        <table class="tab_listproduct">
            <form enctype="multipart/form-data" action="include/addproduct.inc.php", method="POST">
                <tr>
                    <td>
                        Choisissez une catégorie:
                    </td>
                    <td>
                        <select name="listcatname" required>
                            <option value="">Choisir une catégorie</option>   
                            <?php
                                echo $options; ?>
                        </select>
                    </td>
                </tr> 
                <tr>
                    <td>
                        Choisissez une sous-catégorie:
                    </td>
                    <td>
                        <select name="listsubcatname" required>
                            <option value="">Choisir une sous-catégorie</option>   
                            <?php 

                            echo $subcat; ?>
                        </select>
                    </td>
                </tr>               
                    <td>
                        Nom du produit:
                    </td>
                    <td>
                        <input class="add_input" type="text" name="productname" placeholder="nom du produit" required>
                    </td>
                <tr>
                    <td>    
                        Prix du produit:
                    </td>
                    <td >
                     <input class="add_input" type="number" step=0.01 min="0.01" name="productprice" placeholder="prix du produit" required>
                    </td>
                </tr>
                <tr>
                    <td>
                        ajouter une image
                    </td>
                    <td> 
                        <input type="file" name="productimg" required>
                    </td>  
                </tr>        
                <tr>
                    <td>
                        ajouter une description
                    </td>
                    <td> 
                        <textarea name = "productdesc" rows="10" cols="40" placeholder="Ajouter une description"></textarea>
                    </td>  
                </tr> 
                <tr>
                    <td>
                        <input class="add_button" type="submit" name="addproduct_submit" value="AJOUTER">
                    </td>
                </tr>
            </form> 
        </table>
    </div>
</body>

