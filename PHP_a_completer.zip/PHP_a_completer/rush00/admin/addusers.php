<?php

    require "admin.php";
    require "../include/db.inc.php";
 
?>
<p class="titres">AJOUTER UN UTILISATEUR</p>
<body>
    <div>
        <table class="tab_listusers">
            <form action="include/addusers.inc.php" method="POST">
                <tr>
                    <td>
                        Choisissez un niveau d'utilisateur:
                    </td>
                    <td>
                        <select name="listleveluser" required>
                        <option value="admin">admin</option>
                        <option value="user">user</option>   
                        </select>
                    </td>
                </tr>           
                    <td>
                        Choisir un nom d'utilisateur:
                    </td>
                    <td>
                        <input class="add_input" type="text" name="username" placeholder="nom de l'utilisateur" required>
                    </td>
                <tr>
                    <td>    
                        Entrer une adresse mail:
                    </td>
                    <td >
                         <input class="add_input" type="text" name="usermail" placeholder="adresse mail" required>
                    </td>
                </tr>
                <tr>
                    <td>    
                        Choisir un mot de passe:
                    </td>
                    <td >
                         <input class="add_input" type="password" name="userpwd" placeholder="mot de passe" required>
                    </td>
                </tr>    
                <tr>
                    <td>
                        <input class="add_button" type="submit" name="addusers_submit" value="AJOUTER">
                    </td>
                </tr>
            </form> 
        </table>
    </div>
</body>

