<?php


    require "admin.php";
    require "../include/db.inc.php";


    $query = "SELECT * FROM users";
    $res = mysqli_query($conn, $query);

?>
<p class="titres">LISTE DES UTILISATEURS</p>
<body>
   <div>
        <table class="tab_listusers">
                <tr>
                          <th>Nom utilisateur</th>
                          <th>Email utilisateur</th>
                          <th>Niveau utilisateur</th>
                </tr>
                <?php
                    while ($row = mysqli_fetch_array($res)) 
                    {
                        echo '
                        <tr>
                            <td>'.$row['nameUsers'].'</td>
                            <td>'.$row['emailUsers'].'</td>
                            <td>'.$row['administrator'].'</td>
                            <td><a class="modif_button" href="modifusers.php?id='.$row['idUsers'].'">Modifier utilisateur</a></td>
                            <td><form action="include/delusers.inc.php" method="POST">
                                <button type="submit" class="del_button" name="delusers_submit" value='.$row['idUsers'].'>supprimer</button>
                            </form></td>

                        </tr>
                        ';
                    }
                ?> 
                <br/ ><br/ ><br/ ><br/ >
                        <td><a class="add_button" href="addusers.php">Ajouter utilisateur</a></td>
                        			
                                                      
        </table>
    </div>
</body> 

