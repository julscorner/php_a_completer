<?php

    require "admin.php";
    require "../include/db.inc.php";
    $id = $_GET['id'];
    $query = "SELECT * FROM users WHERE idProducts = '$id'";
    $res = mysqli_query($conn, $query);
    $row = mysqli_fetch_array($res);
    
?>
<p class="titres">MODIFIER UN UTILISATEUR</p>
<body>
    <div>
        <table class="tab_listusers">
            <form action="include/modifusers.inc.php" method="POST">
                <tr>
                    <td>
                        Modifier le niveau d'utilisateur:
                        <input type="hidden" name="idproduct" value="<?php echo $id ?>">
                        <input type="hidden" name="oldnameproduct" value="<?php echo $row['nameUser'] ?>">
                    </td>
                    <td>
                        <select name="listleveluser" required>
                        <option value="admin">admin</option>
                        <option value="user">user</option>   
                        </select>
                    </td>
                    <td>
                        <input class="modif_button" type="submit" name="modifuser_level_submit" value="MODIFIER">
                    </td>
                </tr>           
                    <td>
                        Modifier le nom d'utilisateur:
                    </td>
                    <td>
                        <input class="add_input" type="text" name="username" placeholder="nom de l'utilisateur">
                    </td>
                    <td>
                        <input class="modif_button" type="submit" name="modifuser_name_submit" value="MODIFIER">
                    </td>
                <tr>
                    <td>    
                        Modifier l'adresse mail:
                    </td>
                    <td >
                         <input class="add_input" type="text" name="usermail" placeholder="adresse mail">
                    </td>
                    <td>
                        <input class="modif_button" type="submit" name="modifuser_mail_submit" value="MODIFIER">
                    </td>
                </tr>
                <tr>
                    <td>    
                        Modifier le mot de passe:
                    </td>
                    <td >
                         <input class="add_input" type="text" name="userpwd" placeholder="mot de passe">
                    </td>
                    <td>
                        <input class="modif_button" type="submit" name="modifuser_pwd_submit" value="MODIFIER">
                    </td>
                </tr>    
                <tr>
                    <td>
                        <input class="add_button" type="submit" name="addusers_submit" value="AJOUTER">
                    </td>
                </tr>
            </form> 
        </table>
    </div>
</body>

