<?php

    require "admin.php";
    require "../include/db.inc.php";

    $sql = "SELECT * FROM category";
    $res = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_array($res))
    {
        $options = $options."<option>$row[nameCategory]</option>";
    }
?>

<p class="titres">SUPPRIMER UNE CATÉGORIE</p>
 <body>
    <div>
        <table class="tab_delcategory">
            <form action="include/delcategory.inc.php", method="POST">
                <tr>            
                        <td>
                            <select class="ddmenu" name="categoryname" required>
                            <option value="">Choisir une catégorie</option>    
                            <?php echo $options; ?>
                            </select>
                        </td>
                        <td> 
                            <input class="del_button" type="submit" name="delcategory_submit" value="SUPPRIMER">
                        </td>
                </tr>
            </form>                
        </table>
        <?php
            if (isset($_GET['erreur']) || isset($_GET['categorie']))
            {
                echo '<div class="delcat_msg">';
                if ($_GET['categorie'] == 'supprimer')
                    echo '<p>Catégorie supprimé avec succes</p>';
                if ($_GET['erreur'] == 'champsvide')
                    echo '<p>Veuillez selectionner catégorie</p>';
                echo '</div>';
            }
            ?> 
    </div>
</body> 


