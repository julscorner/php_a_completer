<?php

require "header.php";
require "include/db.inc.php";
?>
<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>Panier</h2>

<?php
if (count($_SESSION["shopping_cart"]) == 0) {
    echo '<h1>Rien dans le panier pour le moment</h1>';
}
else {
    echo '
    <table class="cart">
      <tr>
        <th>Nom</th>
        <th>Quantité</th>
        <th>Prix</th>
        <th>Supprimer</th>
      </tr>';
      $query = "SELECT * FROM products";  
      $result = mysqli_query($conn, $query);
      $i = 0;
      $j = 0;
      $n = 0;
      if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) 
        {
            $_SESSION["products"][$j] = 
            array(
                'idProducts' => $row['idProducts'],
                'nameProducts' => $row['nameProducts'],
                'priceProducts' => $row['priceProducts'],
                'imgProducts' => $row['imgProducts']
            );
            $j = $j + 1; 
        }
        foreach ($_SESSION["shopping_cart"] as $shopping_item) 
        {
          
            while ($n < $j)
            {
                if ($_SESSION["products"][$n]['idProducts'] == $shopping_item["item_id"]) {
                    echo '<tr>
                    <td>'.$_SESSION["products"][$n]['nameProducts'].'</td>
                    <td>1</td>
                    <td>'.$_SESSION["products"][$n]['priceProducts'].'</td>
                    <td><a href="cart.php?action=delete&id='.$shopping_item["item_id"].'"><span class="txt-failed">Remove</span></a></td>
                  </tr>';
                  $_SESSION["final_price"][$i] = $_SESSION["products"][$n]['priceProducts'];
                  $i = $i + 1;
                }
                $n = $n + 1;
            }
            $n = 0;
        }
        

      } else {
          echo '<h2 style="color:red;margin:0 auto;" >Oups, désolé ! Il n\'y a pas de produits à afficher</h2>';
      }
      /*echo '<h2>';  echo 'session products '.print_r($_SESSION["products"]); echo'</h2>';*/
      $final_price = 0;
      for ($p = 0; $p < $i; $p++){
        //echo '<h2>';  print_r($_SESSION["final_price"]); echo'</h2>';
        $price = $_SESSION["final_price"][$p] ;
       // echo '<h2>';  echo 'price   '.$price; echo'</h2>';
        $final_price = $price + $final_price;
        //echo '<h2>';  echo 'final price   '.$final_price; echo'</h2>';
    }
      echo '
      <tr>
      <td></td>
      <td>Prix total</td>
      <td>'.$final_price.'</td>
    </tr>
    </table>';
}
if(isset($_GET['action']))
  {
      if($_GET['action'] == "delete")
      {
          foreach ($_SESSION["shopping_cart"] as $keys => $values)
          {
              if ($values['item_id'] == $_GET['id'])
              {
                  unset($_SESSION["shopping_cart"][$keys]);
                  $message = '<h1 style="text-align: center" class="txt-success">Item Removed</h1>';
                  header("Refresh:0");
              }
          }
      }
  }


  ?>

</body>
</html>
