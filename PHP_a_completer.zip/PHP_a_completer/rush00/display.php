<?php    

    require "header.php";
       
?>
<body> 
    
   <div><div class="flex">
  
       <?php
            if(isset($_POST['film_submit']))
            {  
                
                ?>
                <div class="title_cat">
                    <p> Voici notre collection de films</p>
                </div>
                <br/ >
                <?php

                require "include/db.inc.php";


                $query = "SELECT * FROM products WHERE catProducts = 'FILM'";
                $result = mysqli_query($conn, $query);  
                while ($row = mysqli_fetch_array($result)) 
                {
                    echo '<div class="card">
                    <img width="300px" src="'.substr($row['imgProducts'], 3).'">
                    <p >'. $row['nameProducts'].'</p>
                    <form method="POST" action="addtocart.php">
                    <p class="price">'.$row['priceProducts'].'</p>
                    <p>'.$row['descProducts'].'</p>
                    <button name="add_to_cart" class="card_button" value="Add to cart" />Ajouter au panier</button>
                    <input type="hidden" name="hidden_id" class="form-control" value='.$row['idProducts'].' />
                    </form>
                </div>';
                }
            }

            if(isset($_POST['displayfilm_submit']))
            {  
            
                require "include/db.inc.php";

                $cat = $_POST['displayfilm_submit'];

                $query = "SELECT * FROM products WHERE subcatProducts = '$cat' AND catProducts = 'FILM'";
                $result = mysqli_query($conn, $query);                  
                ?>
                <div class="title_cat">
                    <p> Voici notre collection de films <?php echo "$cat"?></p>
                </div>
                <br/ >
                <?php
                
                while ($row = mysqli_fetch_array($result)) 
                {
                    echo '<div class="card">
                    <img width="300px" src="'.substr($row['imgProducts'], 3).'">
                    <p >'. $row['nameProducts'].'</p>
                    <form method="POST" action="addtocart.php">
                    <p class="price">'.$row['priceProducts'].'</p>
                    <p>'.$row['descProducts'].'</p>
                    <button name="add_to_cart" class="card_button" value="Add to cart" />Ajouter au panier</button>
                    <input type="hidden" name="hidden_id" class="form-control" value='.$row['idProducts'].' />
                    </form>
                </div>';
                }
            }
            if(isset($_POST['serie_submit']))
            {  
            
                ?>
                <div class="title_cat">
                    <p> Voici notre collection de séries</p>
                </div>
                <br/ >
                <?php
                
                require "include/db.inc.php";


                $query = "SELECT * FROM products WHERE catProducts = 'SÉRIE'";
                $result = mysqli_query($conn, $query);  
 
                while ($row = mysqli_fetch_array($result)) 
                {
                    echo '<div class="card">
                    <img width="300px" src="'.substr($row['imgProducts'], 3).'">
                    <p >'. $row['nameProducts'].'</p>
                    <form method="POST" action="addtocart.php">
                    <p class="price">'.$row['priceProducts'].'</p>
                    <p>'.$row['descProducts'].'</p>
                    <button name="add_to_cart" class="card_button" value="Add to cart" />Ajouter au panier</button>
                    <input type="hidden" name="hidden_id" class="form-control" value='.$row['idProducts'].' />
                    </form>
                </div>';
                }
            }
            if(isset($_POST['displayserie_submit']))
            {  
                require "include/db.inc.php";

                $cat = $_POST['displayserie_submit'];

                $query = "SELECT * FROM products WHERE subcatProducts = '$cat' AND catProducts = 'SÉRIE'";
                $result = mysqli_query($conn, $query);  
                ?>
                <div class="title_cat">
                    <p> Voici notre collection de films <?php echo "$cat"?></p>
                </div>
                <br/ >
                <?php
                while ($row = mysqli_fetch_array($result)) 
                {
                    echo '<div class="card">
                    <img width="300px" src="'.substr($row['imgProducts'], 3).'">
                    <p >'. $row['nameProducts'].'</p>
                    <form method="POST" action="addtocart.php">
                    <p class="price">'.$row['priceProducts'].'</p>
                    <p>'.$row['descProducts'].'</p>
                    <button name="add_to_cart" class="card_button" value="Add to cart" />Ajouter au panier</button>
                    <input type="hidden" name="hidden_id" class="form-control" value='.$row['idProducts'].' />
                    </form>
                </div>';
                }
            } 
            if(isset($_POST['anime_submit']))
            {              
                
                ?>
                <div class="title_cat">
                    <p> Voici notre collection d'animés</p>
                </div>
                <br/ >
                <?php
                
                require "include/db.inc.php";


                $query = "SELECT * FROM products WHERE catProducts = 'ANIMÉ'";
                $result = mysqli_query($conn, $query);  
                    while ($row = mysqli_fetch_array($result)) 
                {
                    echo '<div class="card">
                    <img width="300px" src="'.substr($row['imgProducts'], 3).'">
                    <p >'. $row['nameProducts'].'</p>
                    <form method="POST" action="addtocart.php">
                    <p class="price">'.$row['priceProducts'].'</p>
                    <p>'.$row['descProducts'].'</p>
                    <button name="add_to_cart" class="card_button" value="Add to cart" />Ajouter au panier</button>
                    <input type="hidden" name="hidden_id" class="form-control" value='.$row['idProducts'].' />
                    </form>
                </div>';
                }
            }
            if(isset($_POST['displayanime_submit']))
            {  
                require "include/db.inc.php";

                $cat = $_POST['displayanime_submit'];

                $query = "SELECT * FROM products WHERE subcatProducts = '$cat' AND catProducts = 'ANIMÉ'";
                $result = mysqli_query($conn, $query);  
                ?>
                <div class="title_cat">
                    <p> Voici notre collection d'animé <?php echo "$cat"?></p>
                </div>
                <br/ >
                <?php
                while ($row = mysqli_fetch_array($result)) 
                {
                    echo '<div class="card">
                    <img width="300px" src="'.substr($row['imgProducts'], 3).'">
                    <p >'. $row['nameProducts'].'</p>
                    <form method="POST" action="addtocart.php">
                    <p class="price">'.$row['priceProducts'].'</p>
                    <p>'.$row['descProducts'].'</p>
                    <button name="add_to_cart" class="card_button" value="Add to cart" />Ajouter au panier</button>
                    <input type="hidden" name="hidden_id" class="form-control" value='.$row['idProducts'].' />
                    </form>
                </div>';
                }
            }  

?>
     </div>
    
</body> 


