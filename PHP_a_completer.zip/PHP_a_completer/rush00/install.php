<?php

$filename = 'rush00.sql';
$host = "127.0.0.1";  
$username = "root";  
$password = "qweqwe";  
$database = "rush00";  

$con = mysqli_connect($host, $username, $password, $database);
if (mysqli_connect_errno()) {
	printf("Échec de la connexion : %s\n", mysqli_connect_error());
	exit();
}

$templine = '';

$lines = file($filename);

foreach ($lines as $line) {

    if (substr($line, 0, 2) == '--' || $line == '')
        continue;

    $templine .= $line;
    if (substr(trim($line), -1, 1) == ';') {
        mysqli_query($con, $templine) or print('Error performing query \'<strong>' . $templine . '\': ' . mysqli_connect_error() . '<br /><br />');
        $templine = '';
    }
}
echo "Tables imported successfully";