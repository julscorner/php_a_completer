<?php
require "header.php";


if (isset($_SESSION['userid']))
{
    echo '<h1 align="center">Vous etes connecté </h1>';
}
else
{
    echo "<h1 align=\"center\">Page d'accueil</h1>";
}
?>

<body>
   <div><div class="flex">
    <?php       
       require "include/db.inc.php";    
            $query = "SELECT * FROM products";  
            $result = mysqli_query($conn, $query);  
            if (mysqli_num_rows($result) > 0) {

                
                while ($row = mysqli_fetch_array($result)) 
                {
                    $id = $row['idProducts'];
                    echo '<div class="card">
                    <img width="300px" src="'.substr($row['imgProducts'], 3).'">
                    <p>'. $row['nameProducts'].'</p>
                    <form method="POST" action="addtocart.php">
                    <p class="price">'.$row['priceProducts'].'</p>
                    <p class="product_description" >'.$row['descProducts'].'</p>
                    <button name="add_to_cart" class="card_button" value="Add to cart" />Ajouter au panier</button>
                    <input type="hidden" name="hidden_id" class="form-control" value='.$row['idProducts'].' />
                    </form>
                  </div>';
                }
            } else {
                echo '<h2 style="color:red;margin:0 auto;" >Oups, désolé ! Il n\'y a pas de produits à afficher</h2>';
            }
    ?>
     </div>
    </div>  
    

</body> 
