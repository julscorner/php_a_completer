<?php
session_start();
require "header.php";

if (empty($_SESSION))
    $_SESSION['logout']= "teste";

if (!isset($_SESSION["shopping_cart"])) 
        $_SESSION["shopping_cart"];

if(isset($_POST["add_to_cart"]))
{

	if(isset($_SESSION["shopping_cart"]))
	{
        $item_array_id = $_SESSION["shopping_cart"];
            $count = count($_SESSION["shopping_cart"]);
			$item_array = array(
                'item_id'			=>	$_POST["hidden_id"],
                'item_quantity'			=>	1,
			);
			$_SESSION["shopping_cart"][$count] = $item_array;
    }
	else
	{
		$item_array = array(
			'item_id'			=>	$_POST["hidden_id"],
			'item_quantity'			=>	1,

		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

//header("location: ".$_SERVER['HTTP_REFERER']);

?>

<body>

<h2 style="margin: 0 300px;">Votre article a bien été ajouté au panier !</h2>
</body>
