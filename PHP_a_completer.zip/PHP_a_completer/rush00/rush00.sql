-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 15, 2019 at 01:07 PM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `idCategory` int(11) NOT NULL,
  `nameCategory` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`idCategory`, `nameCategory`) VALUES
(33, 'action'),
(37, 'comédie'),
(38, 'fantastique'),
(39, 'thriller'),
(40, 'romance');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `idProducts` int(11) NOT NULL,
  `nameProducts` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `priceProducts` decimal(18,2) NOT NULL,
  `imgProducts` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `descProducts` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `subcatProducts` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `catProducts` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`idProducts`, `nameProducts`, `priceProducts`, `imgProducts`, `descProducts`, `subcatProducts`, `catProducts`) VALUES
(32, 'Les enfants du Paradis', '25.00', '../img/images.jpg', 'Paris, fin des années 1930. Sur le boulevard du Crime, le mime Baptiste Deburau, par son témoignage muet, sauve Garance d\'une erreur judiciaire. ', 'romance', 'FILM'),
(33, 'Le chateau ambulant', '16.00', '../img/download.jpg', 'Sophie, une orpheline de 18 ans, travaille dur dans la boutique de chapelier que lui a laissée son père. Un jour, en ville, elle croise Hauru, un magicien très séduisant mais faible de caractère.', 'fantastique', 'FILM'),
(34, 'Bakemonogatari', '11.00', '../img/download-1.jpg', 'L\'histoire de Bakemonogatari est centrée sur le personnage de Koyomi Araragi, un lycéen de terminale qui a été attaqué par un vampire (puis guéri) peu avant le début de l\'histoire. Celui-ci rencontre d\'autres personnages atteints de maux paranormaux divers et leur vient en aide.', 'fantastique', 'ANIMÉ'),
(35, 'Derek', '15.00', '../img/download-2.jpg', 'Derek Noakes, préposé loyal d\'une maison de soins infirmiers qui ne voit que le bon côté des autres.', 'comédie', 'SÉRIE'),
(36, 'Barry', '13.00', '../img/download-3.jpg', 'Alors qu\'il se rend à Los Angeles pour tuer une cible, Barry, un tueur à gages, se découvre une passion pour le théâtre.', 'thriller', 'SÉRIE'),
(37, 'Dark', '18.00', '../img/download-4.jpg', 'Lorsque deux enfants disparaissent dans une petite ville allemande, son passé tragique refait surface. Quatre familles à la recherche des enfants vont voir leur routine bouleversée et les secrets de chacun vont être mis en lumière.', 'thriller', 'SÉRIE'),
(38, 'Grey\'s Anatomy', '10.00', '../img/download-5.jpg', 'C\'est l\'histoire de Meredith Grey, interne, résidente puis titulaire en médecine à l\'hôpital de Seattle Grace, qui a un lien, parfois direct, avec la plus part des docteurs et chirurgiens de cet hôpital. ', 'romance', 'SÉRIE'),
(39, 'How I Met Your Mother', '12.00', '../img/download-6.jpg', 'La série débute en 2030, lorsque Ted Mosby raconte à ses deux enfants comment il a rencontré leur mère.', 'comédie', 'SÉRIE'),
(40, 'Old boy', '9.00', '../img/download-7.jpg', 'Fin des années 80, Oh Dae-Soo, père de famille sans histoire, est enlevé un jour sans raison. Séquestré pendant des années dans une cellule, son seul lien avec l\'extérieur est une télévision.', 'thriller', 'FILM'),
(41, 'Lady vengeance', '11.00', '../img/download-8.jpg', 'Geum-ja devient un personnage public lorsqu\'elle est accusée à seulement 19 ans de l\'enlèvement et du meurtre d\'un petit garçon de cinq ans.', 'thriller', 'FILM'),
(42, 'Hunter x Hunter', '12.00', '../img/download-9.jpg', 'Gon Freecss a douze ans, et rêve de devenir hunter. Les hunters sont des aventuriers d\'élite qui peuvent être chasseurs de prime, chefs-cuisinier, archéologues, zoologues, justiciers ou consultants dans divers domaines.', 'action', 'ANIMÉ'),
(43, 'Fullmetal Alchemist: Brotherhood', '14.00', '../img/download-10.jpg', 'Dans le monde surnaturel de cet anime, les frères Edward et Alphonse combattent des forces malfaisantes pour récupérer leurs corps après avoir souffert dans leur chair.', 'action', 'ANIMÉ'),
(44, 'Fairy Tail', '10.00', '../img/download-11.jpg', 'Dans le royaume de Fiore, il existe des hommes et des femmes qui manipulent la magie', 'comédie', 'ANIMÉ'),
(45, 'Clannad', '5.00', '../img/download-12.jpg', 'Tomoya Okasaki est en troisième année au lycée et est considéré comme délinquant.', 'romance', 'ANIMÉ'),
(46, 'Inception', '20.00', '../img/download-13.jpg', 'Dom Cobb est un voleur expérimenté dans l\'art périlleux de `l\'extraction\' : sa spécialité consiste à s\'approprier les secrets les plus précieux d\'un individu, enfouis au plus profond de son subconscient, pendant qu\'il rêve et que son esprit est particulièrement vulnérable. ', 'action', 'FILM'),
(47, 'Joyeuse retraite !', '9.00', '../img/download-14.jpg', 'Marilou et Philippe se préparent à leur future retraite au Portugal, pour enfin goûter à un peu de tranquillité sous le soleil. Cependant, lorsque leur fille se sépare de son petit ami avec perte et fracas, tout un cortège de sollicitations s\'abat sur eux.', 'comédie', 'FILM'),
(48, 'Arrow', '17.00', '../img/download-15.jpg', 'Les nouvelles aventures de Green Arrow/Oliver Queen. Disparu en mer avec son père et sa petite amie, il est retrouvé vivant 5 ans plus tard sur une île près des côtes Chinoises.', 'action', 'SÉRIE'),
(49, 'Game of Thrones', '15.00', '../img/download-16.jpg', 'Neuf familles nobles rivalisent pour le contrôle du Trône de Fer dans les sept royaumes de Westeros. Pendant ce temps, des anciennes créatures mythiques oubliées reviennent pour faire des ravages.', 'fantastique', 'SÉRIE'),
(50, 'Parasite', '15.00', '../img/download-17.jpg', 'Des sphères abritant des parasites arrivent sur terre et menacent l\'humanité. L\'histoire nous entraîne au coté de Shinichi, un lycéen qui possède un parasite à son bras droit.', 'thriller', 'SÉRIE'),
(51, 'Deadman Wonderland', '13.00', '../img/download-18.jpg', 'La vie de Ganta Igarashi, change quand un homme en armure flotte devant les fenêtres de la classe.', 'fantastique', 'ANIMÉ'),
(52, 'Death Note', '13.00', '../img/download-19.jpg', 'Un carnet maléfique (Death Note) tombe entre les mains de Light Yagami, un adolescent de 17 ans. Ce cahier a un pouvoir maléfique : si quelqu\'un note un nom sur ses pages, la personne en question meurt quelques secondes plus tard.', 'fantastique', 'ANIMÉ'),
(53, 'La la land', '20.00', '../img/download-20.jpg', 'Au coeur de Los Angeles, une actrice en devenir prénommée Mia sert des cafés entre des auditions. De son côté, Sebastian, passionné de jazz, joue du piano dans des clubs miteux pour assurer sa subsistance. ', 'romance', 'FILM'),
(54, 'Silent Voice', '12.00', '../img/download-21.jpg', 'Nishimiya est une élève douce et attentionnée. Chaque jour, pourtant, elle est harcelée par Ishida, car elle est sourde. Dénoncé pour son comportement, le garçon est à son tour mis à l\'écart et rejeté par ses camarades. Des années plus tard, il apprend la langue des signes... et part à la recherche de la jeune fille. ', 'romance', 'FILM'),
(55, 'The Dark Knight : Le Chevalier noir', '17.00', '../img/download-22.jpg', 'Batman entreprend de démanteler les dernières organisations criminelles de Gotham. Mais il se heurte bientôt à un nouveau génie du crime qui répand la terreur et le chaos dans la ville : le Joker.', 'action', 'FILM'),
(56, 'Matrix', '11.00', '../img/download-23.jpg', 'Programmeur anonyme, Thomas Anderson est aussi l\'un des pirates les plus recherchés du cyber-space. Il est contacté par un certain Morpheus. Ensemble, ils se lancent dans une lutte sans retour contre la Matrice et ses terribles agents.', 'action', 'FILM'),
(57, 'Avengers: Endgame', '8.00', '../img/download-24.jpg', 'Thanos ayant anéanti la moitié de l’univers, les Avengers restants resserrent les rangs dans ce vingt-deuxième film des Studios Marvel, grande conclusion d’un des chapitres de l’Univers Cinématographique Marvel.', 'fantastique', 'FILM'),
(58, 'Chobits', '11.00', '../img/download-26.jpg', 'Hideki Motosuwa décide d\'aller suivre des cours de rattrapage à Tokyo. Il se trouve également un petit travail, pour se faire un peu d\'argent. C\'est dans cette ville qu\'il y découvre les `persocom\', des ordinateurs personnels à forme humaine.', 'comédie', 'SÉRIE'),
(59, 'La ligne verte', '25.00', '../img/download-27.jpg', 'Paul Edgecomb, pensionnaire centenaire d\'une maison de retraite, est hanté par ses souvenirs. Gardien-chef du pénitencier de Cold Mountain, en 1935, en Louisiane, il était chargé de veiller au bon déroulement des exécutions capitales au bloc E (la ligne verte) en s\'efforçant d\'adoucir les derniers moments.', 'fantastique', 'FILM'),
(60, 'Dexter', '17.00', '../img/download-28.jpg', 'De jour, l\'avenant Dexter est expert médico-légal en analyse de traces de sang pour la police de Miami. De nuit, c\'est un tueur en série qui s\'attaque aux meurtriers.', 'thriller', 'SÉRIE'),
(61, 'Mme Maisel, femme fabuleuse', '15.00', '../img/download-29.jpg', 'Miriam « Midge » Maisel (Rachel Brosnahan) est mère au foyer juive vivant dans un bel appartement new-yorkais en 1958. Son mari, Joel (Michael Zegen), est un homme d\'affaires qui fait un soir par semaine du stand-up dans un café de Greenwich Village le Gaslight Café.', 'comédie', 'SÉRIE'),
(62, 'Louie', '11.00', '../img/download-30.jpg', 'Tout juste célibataire, un comique tente d\'élever ses deux filles à New York tout en s\'essayant aux rendez vous amoureux.', 'comédie', 'SÉRIE'),
(63, 'Les Demoiselles du téléphone', '15.00', '../img/download-31.jpg', 'La série se déroule en 1928 et prend place à Madrid. Grâce à leur travail de standardistes dans la compagnie de téléphone de la capitale, quatre jeunes femmes en quête d’indépendance vont créer des liens et vivre des aventures plus fortes les unes que les autres.', 'romance', 'SÉRIE');

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `idType` int(11) NOT NULL,
  `nameType` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`idType`, `nameType`) VALUES
(1, 'FILM'),
(2, 'SÉRIE'),
(3, 'ANIMÉ');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `idUsers` int(11) NOT NULL,
  `nameUsers` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `emailUsers` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pwdUsers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `administrator` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`idUsers`, `nameUsers`, `emailUsers`, `pwdUsers`, `administrator`) VALUES
(4, 'root', 'root@gmail.com', '06948d93cd1e0855ea37e75ad516a250d2d0772890b073808d831c438509190162c0d890b17001361820cffc30d50f010c387e9df943065aa8f4e92e63ff060c', 'admin'),
(6, 'qwe', 'qwe@gmail.com', '840decb656926fc5d8dd2f2f62587355064eb9fdd9fc73933a54406a2f6e8ff5e203512afc70f223b3bbe7c2ba32c2e29443569ea240d6f4a4fb6afa1f43d8be', 'user'),
(7, 'alex', 'qwe@gmail.com', 'ac5bbf8b24d2db584f0dcc26e738ec41f2fabb971851fb17aa3475587df5836346ea422378bdd654dafca3fe62033135dbec46b63b27fb4d13da78ee0e6bbe8d', 'user'),
(8, 'alexsoysavanh', 'qwe@gmail.com', 'ac5bbf8b24d2db584f0dcc26e738ec41f2fabb971851fb17aa3475587df5836346ea422378bdd654dafca3fe62033135dbec46b63b27fb4d13da78ee0e6bbe8d', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`idCategory`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`idProducts`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`idType`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idUsers`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `idCategory` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `idProducts` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `idType` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `idUsers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
