<?php
if (isset($_POST['submit']))
{
     require 'db.inc.php';
     $username = $_POST['login'];
     $email = $_POST['email'];
     $passwd = $_POST['passwd'];
     $passwdconfirm = $_POST['confirm_passwd'];
     $user = "user";
     // error empty fields

     if (empty($username) || empty($email) || empty($passwd) || empty($passwdconfirm))
     {
          header("location: ../signup.php?erreur=champsvide&login=".$username."&mail=".$email);
          exit();
     }

     // error invalide mail and login

     else if (!filter_var($email, FILTER_VALIDATE_EMAIL) && !preg_match("/^[a-zA-Z0-9]*$/", $username))
     {
          header("location: ../signup.php?erreur=loginmailinvalide");
          exit();
     }

     // error invalide mail

     else if (!filter_var($email, FILTER_VALIDATE_EMAIL))
     {
          header("location: ../signup.php?erreur=mailinvalide&login=".$username);
          exit();
     }

     // error invalide username 

     else if (!preg_match("/^[a-zA-Z0-9]*$/", $username))
     {
          header("location: ../signup.php?erreur=logininvalide&mail=".$email);
          exit();
     }

     // error check passwd

     else if ($passwd !== $passwdconfirm)
     {
          header("location: ../signup.php?erreur=verificationmotdepasse&login=".$username."$mail=".$email);
          exit();
     }

     // check if login already used

     else 
     {
          $sql = "SELECT nameUsers FROM users WHERE nameUsers=?";
          $stmt = mysqli_stmt_init($conn);                                 //Initialise une commande MySQL
          if (!mysqli_stmt_prepare($stmt, $sql))                           //Prépare une requête SQL pour l'exécution
          {
               header("location: ../signup.php?erreur=erreursql");
               exit();
          }
          else
          {
               mysqli_stmt_bind_param($stmt, "s", $username);               // Lie des variables à une requête MySQL
               mysqli_stmt_execute($stmt);                                  // Exécute une requête préparée
               mysqli_stmt_store_result($stmt);                             // Stocke un jeu de résultats depuis une requête préparée
               $resultCheck = mysqli_stmt_num_rows($stmt);                  //Retourne le nombre de lignes d'un résultat MySQL
               if ($resultCheck > 0)
               {
                    header("location: ../signup.php?error=nomutilisateurdéjàexistant&mail=".$email);
                    exit();
               }
               else
               {
                    $sql = "INSERT INTO users(nameUsers, emailUsers, pwdUsers, administrator) VALUES (?, ?, ?, ?)";
                    $stmt = mysqli_stmt_init($conn);
                    if (!mysqli_stmt_prepare($stmt, $sql))
                    {
                         header("location: ../signup.php?erreur=erreursql");
                         exit();
                    }
                    else 
                    {
                         $hashpasswd= hash('whirlpool', $passwd);
                         mysqli_stmt_bind_param($stmt, "ssss", $username, $email, $hashpasswd, $user);
                         mysqli_stmt_execute($stmt);
                         header("location: ../signup.php?inscription=réussi");
                         exit();
                    }

               }
          }
     }
     mysqli_stmt_close($stmt);
     mysqli_close($conn);
}
else
{
     header("location: ../signup.php");
     exit();
}