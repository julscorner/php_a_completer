<?php
$servername = "127.0.0.1";
$dbusername = "root";
$dbpasswd = "qweqwe";
$dbname = "rush00";

$conn = mysqli_connect($servername, $dbusername, $dbpasswd, $dbname);

if (!$conn)
{
    die("Connexion echoué: ".mysqli_connect_error());
}
