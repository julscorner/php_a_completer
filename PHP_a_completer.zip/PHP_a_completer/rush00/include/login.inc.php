<?php
if (isset($_POST['submit']))
{
    require "db.inc.php";

    $login = $_POST['login'];
    $passwd = $_POST['passwd'];

    if (empty($login) || empty($passwd))
    {
        header("location: ../index.php?erreur=champsvide");
        exit();
    }
    else
    {
        $sql = "SELECT * FROM users WHERE nameUsers=?";
        $stmt = mysqli_stmt_init($conn);

        if (!mysqli_stmt_prepare($stmt, $sql))
        {
            header("location: ../index.php?erreur=erreursql");
            exit();
        }
        else if (mysqli_stmt_prepare($stmt, $sql))
        {
            mysqli_stmt_bind_param($stmt, "s", $login);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            if ($row = mysqli_fetch_assoc($result))                            //Récupère une ligne de résultat sous forme de tableau associatif
            {
                $hashpasswd = hash('whirlpool', $passwd);
                if ($hashpasswd !== $row['pwdUsers'])
                {
                    header("location: ../index.php?erreur=mauvaismotdepasse");
                    exit();
                }
                else
                {
                    if ($row['administrator'] == 'admin')
                    {
                        session_start();
                        $_SESSION['adminid'] = 'admin';
                        header("location: ../admin/listproduct.php?connexion=reussi");
                        exit();
                    }
                    else
                    {
                        session_start();
                        $_SESSION['userid'] = $row['idUsers'];
                        $_SESSION['username'] = $row['nameUsers'];
                        header("location: ../index.php?connexion=réussi");
                        exit();
                    }
                }
            }
            else
            {
                header("location: ../index.php?erreur=loginabsent");
                exit();
            }
        }
    }
}
else
{
    header("location: ../index.php");
    exit();
}