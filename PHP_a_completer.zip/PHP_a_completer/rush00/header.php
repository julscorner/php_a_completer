<?php
session_start();

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style_user.css?version=2">
        <title>Adopte un film</title>
    </head>

    <header>
    <div id="page">
        <a href="index.php"><img src="img/logo.jpg" alt="logo"></a> 
       

     <nav>  
            <div class="menu">
                    <td><form action="display.php" method="POST">
                        <button class="button_cat" type="submit" name="film_submit" value='FILM'>Films</button>
                    </form></td>
                    <?php
                    require "include/db.inc.php";
                
                        $query = "SELECT * FROM category ORDER BY nameCategory";
                        $res = mysqli_query($conn, $query);
                            while ($row = mysqli_fetch_array($res)) 
                            {
                                echo '
                                <td><form action="display.php" method="POST">
                                    <button class="button" type="submit" name="displayfilm_submit" value='.$row['nameCategory'].'>'.$row['nameCategory'].'</button>
                                </form></td>
                                ';
                            }
                    ?> 
                    <td><form action="display.php" method="POST">
                        <button class="button_cat" type="submit" name="serie_submit" value='SERIE'>Séries</button>
                    </form></td>
                    <?php
                    require "include/db.inc.php";
                
                        $query = "SELECT * FROM category ORDER BY nameCategory";
                        $res = mysqli_query($conn, $query);
                            while ($row = mysqli_fetch_array($res)) 
                            {
                                echo '
                                <td>
                                <td><form action="display.php" method="POST">
                                    <button class="button" type="submit" name="displayserie_submit" value='.$row['nameCategory'].'>'.$row['nameCategory'].'</button>
                                </form></td>
                                </tr>
                                ';
                            }
                    ?> 
                    <td><form action="display.php" method="POST">
                        <button class="button_cat" type="submit" name="anime_submit" value='ANIME'>Animé</button>
                    </form></td>
                    <?php
                    require "include/db.inc.php";
                
                        $query = "SELECT * FROM category ORDER BY nameCategory";
                        $res = mysqli_query($conn, $query);
                            while ($row = mysqli_fetch_array($res)) 
                            {
                                echo '
                                <td>
                                <td><form action="display.php" method="POST">
                                    <button class="button" type="submit" name="displayanime_submit" value='.$row['nameCategory'].'>'.$row['nameCategory'].'</button>
                                </form></td>
                                </tr>
                                ';
                            }
                    ?> 
            </div>
        </nav>
    

    <div class="cart">
        <table>
    
       
        </table>
    </div> 




    </div>
    <div>
        <nav>                
            <div class="carticon">
            <a href="cart.php"><img src="img/cart-icon.png" alt="cart"/></a>
            </div>
            <div class="log">
                <?php
                


                if (isset($_SESSION['userid']))
                {                

                    echo '<form action="include/login.inc.php" method="POST">
                    <p class="login2">bienvenue '.$_SESSION['username'].'</p>
                    <a class="signup" href="include/logout.inc.php">Déconnexion</a>
                </form>';
                }
                else 
                {
                    echo '<form action="include/login.inc.php" method="POST">
                    <input class="login" type="text" placeholder="Nom utilisateur" name="login" value="" required>
                    <input class="login" type="text" placeholder="Mot de passe" name="passwd" value="" required>
                    <input class="login_button" type="submit" name="submit" value="Se connecter" required>
                    <a class="signup" href="signup.php">Inscription</a>
                </form>';
                }


                ?>
            </div>
        </nav>
    </div>    <?php 
                           if ($_GET['erreur'] == "loginabsent")
                        echo ' <p class="message">Ce compte n\'existe pas</p> ';
    ?>
       
    </header>
    <body>
    
 
    </body>
</html>